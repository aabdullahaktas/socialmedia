package com.bilgeadam.repository.enums;

public enum ERole {
    USER,ADMIN
}
